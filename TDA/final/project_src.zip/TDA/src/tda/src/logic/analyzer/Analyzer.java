package tda.src.logic.analyzer;

public interface Analyzer {

	public void analyze();

}
